# Quantum Pulse Maze (QPM)

**Quantum Pulse Maze (QPM)** is a post-quantum cryptography (PQC) system designed to withstand quantum computing attacks by utilizing **pulse-based phase and delay encoding**.

> 🧠 Developed by **Seungheon Yeom**, Paju, Korea  
> 🛡️ For research, education, and futuristic cryptography applications.

---

## 🚀 Features

- 🔐 **QPM Encryption**: Uses quantum-inspired encoding of phase and time delay.
- 🧪 **Simulation Modules**: Failure maps, noise testing, and VM emulator.
- 💬 **Streamlit Interface**: User-friendly demo for live encryption/decryption.
- 🧱 **API Support**: FastAPI-powered backend for web integration.
- 📈 **3D Error Visualization**: Visual tools to demonstrate noise resistance.

---

## 🗂️ Project Structure

quantum-pulse-maze/ ├── encryption/ # Core logic and simulations │ ├── QPM_암호화_복호화_시뮬레이션.py │ ├── QPM_RandomNoise_v1.py │ ├── QPM_NoiseMap_3D_English.py │ └── QPM_VM_시뮬레이터.py ├── app/ # App interface (CLI, API, GUI) │ ├── QChatGPT_앱_Streamlit.py │ ├── QChatGPT_API_실제연결버전.py │ └── QChatGPT_메신저.py ├── README.md # You're reading it └── LICENSE # MIT license

yaml
복사
편집

---

## 🔧 Requirements

Install dependencies via pip:

```bash
pip install numpy streamlit matplotlib fastapi uvicorn
To run the Streamlit app:

bash
복사
편집
streamlit run app/QChatGPT_앱_Streamlit.py
To run the API server:

bash
복사
편집
uvicorn app.QChatGPT_API_실제연결버전:app --reload
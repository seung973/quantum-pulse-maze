import numpy as np

# 암호화 함수
def qpm_encrypt(msg, phase_key, delay_key):
    return [
        ord(c) * np.exp(1j * phase_key[i % len(phase_key)]) + delay_key[i % len(delay_key)]
        for i, c in enumerate(msg)
    ]

# 복호화 함수
def qpm_decrypt(cipher, phase_key, delay_key):
    decrypted = ''
    for i, val in enumerate(cipher):
        guess = np.real((val - delay_key[i % len(delay_key)]) / np.exp(1j * phase_key[i % len(phase_key)]))
        decrypted += chr(int(round(guess)))
    return decrypted

# 사용자 입력
print("💬 QPM 메신저 시뮬레이터")
msg = input("메시지를 입력하세요: ")
phases = input("위상 키 입력 (예: 1.0,2.1,3.4): ")
delays = input("지연 키 입력 (예: 0.5,1.2,2.1): ")

# 키 처리
phase_key = np.array([float(x) for x in phases.split(",")])
delay_key = np.array([float(x) for x in delays.split(",")])

# 암호화 & 복호화
cipher = qpm_encrypt(msg, phase_key, delay_key)
print("\n🔒 암호화된 데이터:")
print(cipher)

decrypted = qpm_decrypt(cipher, phase_key, delay_key)
print("\n🔓 복호화 결과:")
print(decrypted)

import streamlit as st
import numpy as np

# QPM 암호화/복호화 함수
def qpm_encrypt(msg, phases, delays):
    return [
        ord(char) * np.exp(1j * phases[i % len(phases)]) + delays[i % len(delays)]
        for i, char in enumerate(msg)
    ]

def qpm_decrypt(cipher, phases, delays):
    result = ''
    for i, val in enumerate(cipher):
        guess = np.real((val - delays[i % len(delays)]) / np.exp(1j * phases[i % len(phases)]))
        result += chr(int(round(guess)))
    return result

# Streamlit UI
st.title("🧿 QPM Messenger")
st.markdown("Encrypt messages with Quantum Pulse Maze")

message = st.text_input("Enter your message:", value="HELLO QPM")
phases = st.text_input("Phase key (comma-separated)", value="1.0,2.1,3.4,0.9,1.6")
delays = st.text_input("Delay key (comma-separated)", value="0.5,1.2,2.1,1.8,0.9")

if st.button("Encrypt & Decrypt"):
    phase_key = np.array([float(x) for x in phases.split(",")])
    delay_key = np.array([float(x) for x in delays.split(",")])
    cipher = qpm_encrypt(message, phase_key, delay_key)
    decrypted = qpm_decrypt(cipher, phase_key, delay_key)

    st.success(f"Decrypted: {decrypted}")
    st.code(cipher, language='python')

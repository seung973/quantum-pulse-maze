import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# QPM 암호화/복호화
def encrypt_qpm(msg, phases, delays):
    return [
        ord(char) * np.exp(1j * phases[i % len(phases)]) + delays[i % len(delays)]
        for i, char in enumerate(msg)
    ]

def decrypt_qpm(cipher, phases, delays):
    result = ''
    for i, val in enumerate(cipher):
        guess = np.real((val - delays[i % len(delays)]) / np.exp(1j * phases[i % len(phases)]))
        result += chr(int(round(guess)))
    return result

# 파라미터
true_phase = np.array([1.0, 2.1, 3.4, 0.9, 1.6])
true_delay = np.array([0.5, 1.2, 2.1, 1.8, 0.9])
message = "QPMTEST"

# 3D 좌표용 배열
phi_err_vals = np.linspace(0, 0.2, 21)
delta_err_vals = np.linspace(0, 0.2, 21)
PHI_ERR, DELTA_ERR = np.meshgrid(phi_err_vals, delta_err_vals)
FAIL_RATE = np.zeros_like(PHI_ERR)

# 실험 시작
for i in range(PHI_ERR.shape[0]):
    for j in range(PHI_ERR.shape[1]):
        phi = true_phase + PHI_ERR[i, j]
        delta = true_delay + DELTA_ERR[i, j]
        cipher = encrypt_qpm(message, true_phase, true_delay)
        decrypted = decrypt_qpm(cipher, phi, delta)
        errors = sum([a != b for a, b in zip(message, decrypted)])
        FAIL_RATE[i, j] = errors / len(message)

# 그래프
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(PHI_ERR, DELTA_ERR, FAIL_RATE, cmap='viridis')
ax.set_xlabel("Phase Error")
ax.set_ylabel("Delay Error")
ax.set_zlabel("Failure Rate")
plt.title("QPM Decryption Error Map")
plt.show()


import numpy as np
import random

def encrypt_qpm(message, phase_key, delay_key):
    return [
        ord(char) * np.exp(1j * phase_key[i % len(phase_key)]) + delay_key[i % len(delay_key)]
        for i, char in enumerate(message)
    ]

def decrypt_qpm(ciphertext, phase_key, delay_key):
    result = ''
    for i, val in enumerate(ciphertext):
        guess = np.real((val - delay_key[i % len(delay_key)]) / np.exp(1j * phase_key[i % len(phase_key)]))
        result += chr(int(round(guess)))
    return result

def inject_noise(arr, level=0.05):
    return arr + np.random.normal(0, level, size=arr.shape)

# 원본 키
true_phase = np.array([1.0, 2.1, 3.4, 0.9, 1.6])
true_delay = np.array([0.5, 1.2, 2.1, 1.8, 0.9])

message = "QPM"

# 암호화
cipher = encrypt_qpm(message, true_phase, true_delay)

# 복호화 실험 - 잡음 있는 키
for noise_level in [0.01, 0.05, 0.1, 0.2]:
    noisy_phase = inject_noise(true_phase, level=noise_level)
    noisy_delay = inject_noise(true_delay, level=noise_level)
    decrypted = decrypt_qpm(cipher, noisy_phase, noisy_delay)
    print(f"[Noise {noise_level}] → 복호화 결과: {decrypted}")

import numpy as np

class QPMVirtualMachine:
    def __init__(self, message, phase_key, delay_key):
        self.message = message
        self.phase_key = np.array(phase_key)
        self.delay_key = np.array(delay_key)
        self.cipher = None

    def encrypt(self):
        self.cipher = [
            ord(char) * np.exp(1j * self.phase_key[i % len(self.phase_key)]) + self.delay_key[i % len(self.delay_key)]
            for i, char in enumerate(self.message)
        ]
        return self.cipher

    def decrypt(self, test_phase, test_delay):
        decrypted = ''
        for i, val in enumerate(self.cipher):
            guess = np.real((val - test_delay[i % len(test_delay)]) / np.exp(1j * test_phase[i % len(test_phase)]))
            decrypted += chr(int(round(guess)))
        return decrypted

    def test_error(self, test_phase, test_delay):
        result = self.decrypt(test_phase, test_delay)
        error_count = sum([a != b for a, b in zip(self.message, result)])
        return error_count / len(self.message)


# 예제 실행
if __name__ == "__main__":
    msg = "QPMSECURE"
    phase = [1.0, 2.1, 3.4, 0.9, 1.6]
    delay = [0.5, 1.2, 2.1, 1.8, 0.9]

    vm = QPMVirtualMachine(msg, phase, delay)
    encrypted = vm.encrypt()

    print("암호화 완료. 복호화 테스트...")

    for err in [0.0, 0.05, 0.1, 0.15, 0.2]:
        test_phi = phase + np.full(len(phase), err)
        test_delta = delay + np.full(len(delay), err)
        fail = vm.test_error(test_phi, test_delta)
        print(f"오차 {err:.2f} → 실패율: {fail*100:.1f}%")

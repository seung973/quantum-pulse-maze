import numpy as np
import pandas as pd

# 1. 암호화 및 복호화 함수 정의

def qpm_encrypt(msg, phases, delays):
    return [
        ord(char) * np.exp(1j * phases[i % len(phases)]) + delays[i % len(delays)]
        for i, char in enumerate(msg)
    ]

def qpm_decrypt(cipher, phases, delays):
    result = ''
    for i, val in enumerate(cipher):
        decoded = np.real((val - delays[i % len(delays)]) / np.exp(1j * phases[i % len(phases)]))
        result += chr(int(round(decoded)))
    return result

# 2. 기본값 설정

message = "HELLO"
true_phase = np.array([1.0, 2.1, 3.4, 0.9, 1.6])  # 위상 키
true_delay = np.array([0.5, 1.2, 2.1, 1.8, 0.9])  # 지연 키

# 3. 오차 범위 설정 (0.00 ~ 0.20)

errors = np.round(np.arange(0.0, 0.21, 0.01), 2)
results = []

# 4. 실험 루프

for error in errors:
    # 위상/지연 키에 오차 추가
    phase_error = true_phase + error
    delay_error = true_delay + error

    # 암호화 (원래 키 사용)
    encrypted = qpm_encrypt(message, true_phase, true_delay)

    # 복호화 (오차 키 사용)
    decrypted_phi = qpm_decrypt(encrypted, phase_error, true_delay)
    decrypted_delta = qpm_decrypt(encrypted, true_phase, delay_error)

    # 오류 문자 수 계산
    phi_error_count = sum([a != b for a, b in zip(message, decrypted_phi)])
    delta_error_count = sum([a != b for a, b in zip(message, decrypted_delta)])

    # 결과 저장
    results.append({
        "오차": error,
        "위상 오류 문자 수": phi_error_count,
        "지연 오류 문자 수": delta_error_count,
        "위상 복호화 결과": decrypted_phi,
        "지연 복호화 결과": decrypted_delta
    })

# 5. 결과 출력
df_results = pd.DataFrame(results)
print(df_results)
